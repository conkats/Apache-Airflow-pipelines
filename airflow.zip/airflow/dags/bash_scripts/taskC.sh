echo TASK C has started!
sleep 10
exit 130 #task to fail
echo TASK C has ended!