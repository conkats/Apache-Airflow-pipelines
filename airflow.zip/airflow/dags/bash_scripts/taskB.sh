echo TASK B has started!
sleep 4
exit 99 # skip task with error 99 cpode
echo TASK B has ended!