echo TASK A has started!
            
for i in {1..10}
do
    echo TASK A printing $i
done

echo TASK A has ended!